export class MainService{
    public static lang :string='en';
}